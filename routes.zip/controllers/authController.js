// const User = require("../models/user.model");
// const jwt = require("jsonwebtoken");

// exports.register = async (req, res) => {
//   try {
//     const {
//       fullName,
//       email,
//       contactNo,
//       altContactNo,
//       state,
//       district,
//       city,
//       area,
//       password,
//       role,
//       age,
//       qualifications,
//     } = req.body || {};

//     console.log("Incoming body:", req.body);

//     // Profile Image URL (from DigitalOcean Spaces via multer + uploadToSpaces)
//     let profileImage = null;
//     if (req.file && req.file.location) {
//       profileImage = req.file.location;
//     } else if (req.body.profileImage) {
//       profileImage = req.body.profileImage;
//     }

//     // Required field check
//     if (
//       !profileImage ||
//       !fullName ||
//       !email ||
//       !contactNo ||
//       !state ||
//       !district ||
//       !city ||
//       !password ||
//       !role
//     ) {
//       return res.status(400).json({ message: "Required fields are missing" });
//     }

//     // Validate role
//     if (!User.schema.path("role").enumValues.includes(role)) {
//       return res.status(400).json({ message: "Invalid role selected" });
//     }

//     // Check if user already exists
//     const existingUser = await User.findOne({ email });
//     if (existingUser) {
//       return res.status(400).json({ message: "User already exists" });
//     }

//     // New User creation
//     const newUser = new User({
//       profileImage,
//       fullName,
//       email,
//       contactNo,
//       altContactNo,
//       state,
//       district,
//       city,
//       area,
//       password,
//       role,
//       age,
//       qualifications,
//     });

//     await newUser.save();

//     res.status(201).json({
//       success: true,
//       message: "✅ User registered successfully",
//       user: newUser,
//     });
//   } catch (err) {
//     console.error("❌ Register Error:", err);
//     res.status(500).json({ message: "Server error" });
//   }
// };

// exports.login = async (req, res) => {
//     try {
//         const { email, password } = req.body;

//         if (!email || !password) return res.status(400).json({ message: "Email and password required" });

//         const user = await User.findOne({ email });
//         if (!user) return res.status(400).json({ message: "Invalid credentials" });

//         const isMatch = await user.comparePassword(password);
//         if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

//         const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });

//         res.status(200).json({ token, user: { id: user._id, fullName: user.fullName, email: user.email, role: user.role } });
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ message: "Server error" });
//     }
// };


const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/user.model"); // Ensure this path is correct

// Register User (for all roles including Admin, SuperAdmin)
// This register function will replace the one that uses Admin.findOne
exports.register = async (req, res) => {
  try {
    const {
      fullName,
      email,
      contactNo,
      altContactNo,
      state,
      district,
      city,
      area,
      password,
      role,
      age,
      qualifications,
    } = req.body || {};

    // Profile Image URL (from DigitalOcean Spaces via multer + uploadToSpaces)
    let profileImage = null;
    if (req.file && req.file.location) {
      profileImage = req.file.location;
    } else if (req.body.profileImage) { // Fallback if image comes as URL directly
      profileImage = req.body.profileImage;
    }

    // Required field check (adjust as per your needs for different roles)
    if (
      !profileImage ||
      !fullName ||
      !email ||
      !contactNo ||
      !state ||
      !district ||
      !city ||
      !password ||
      !role
    ) {
      return res.status(400).json({ message: "Required fields are missing" });
    }

    // Validate role
    if (!User.schema.path("role").enumValues.includes(role)) {
      return res.status(400).json({ message: "Invalid role selected" });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "User with this email already exists" });
    }

    // Password hashing is handled by pre-save hook in user.model.js
    const newUser = new User({
      profileImage,
      fullName,
      email,
      contactNo,
      altContactNo,
      state,
      district,
      city,
      area,
      password, // Hashing done in model
      role,
      age,
      qualifications,
    });

    await newUser.save();

    res.status(201).json({
      success: true,
      message: "✅ User registered successfully",
      user: {
        id: newUser._id,
        fullName: newUser.fullName,
        email: newUser.email,
        role: newUser.role,
        profileImage: newUser.profileImage,
        contactNo: newUser.contactNo,
        state: newUser.state,
        district: newUser.district,
        city: newUser.city
      }
    });
  } catch (err) {
    console.error("❌ Register Error:", err);
    res.status(500).json({ message: "Server error occurred. Please try again later." });
  }
};

// Login User (for all roles)
exports.login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ msg: "Please provide all required fields" });
  }

  try {
    let user = await User.findOne({ email });

    if (!user) {
      return res.status(401).json({ message: "Invalid credentials", errorCode: "INVALID_CREDENTIALS" });
    }

    const isMatch = await user.comparePassword(password); // Using method from user.model.js
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid credentials", errorCode: "INVALID_CREDENTIALS" });
    }

    const token = jwt.sign(
      { id: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "30d" } // Increased expiry
    );

    res.status(200).json({
      message: "Login successful",
      token,
      role: user.role,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
        profileImage: user.profileImage,
        contactNo: user.contactNo,
        state: user.state,
        district: user.district,
        city: user.city
      }
    });
  } catch (error) {
    console.error("Error during login:", error.message);
    res.status(500).json({ message: "Server error occurred", errorCode: "SERVER_ERROR" });
  }
};