// const leadModel = require("../models/lead.model");

// // Create Lead
// exports.createLead = async (req, res) => {
//     try {
//         const { name, email, phone, source } = req.body;

//         const lead = new leadModel({
//             name,
//             email,
//             phone,
//             source,
//             createdBy: req.user.id
//         });

//         await lead.save();
//         res.status(201).json({ message: "Lead created successfully", lead });
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ message: "Server error" });
//     }
// };

// // Get all Leads (Admin, SuperAdmin, Telecaller)
// exports.getAllLeads = async (req, res) => {
//     try {
//         let query = {};

//         // Agar telecaller hai -> usko sabhi leads dikhengi
//         if (req.user.role === "telecaller") {
//             query = {}; // Telecaller ko sab dikhegi
//         }

//         // Agar field executive hai -> usko sirf uske assigned leads
//         if (req.user.role === "fieldexecutive") {
//             query = { assignedTo: req.user.id };
//         }

//         const leads = await leadModel.find(query).populate("assignedTo createdBy", "fullName email role");
//         res.status(200).json(leads);
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ message: "Server error" });
//     }
// };

// // Update Lead (edit, status change, assign)
// // exports.updateLead = async (req, res) => {
// //     try {
// //         const { id } = req.params;
// //         const { name, email, phone, status, assignedTo, remark } = req.body;

// //         let lead = await leadModel.findById(id);
// //         if (!lead) return res.status(404).json({ message: "Lead not found" });

// //         if (name) lead.name = name;
// //         if (email) lead.email = email;
// //         if (phone) lead.phone = phone;
// //         if (status) lead.status = status;
// //         if (assignedTo) lead.assignedTo = assignedTo;

// //         if (remark) {
// //             lead.remarks.push({ text: remark, addedBy: req.user.id });
// //         }

// //         await lead.save();

// //         // 🔥 Populate assignedTo details from User model
// //         lead = await leadModel.findById(id)
// //             .populate("assignedTo", "fullName email contact state district city area role");

// //         res.status(200).json({ message: "Lead updated successfully", lead });
// //     } catch (err) {
// //         console.error(err);
// //         res.status(500).json({ message: "Server error" });
// //     }
// // };

// exports.updateLead = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const {
//       promoter,
//       mobileNo,
//       structureType,
//       customerName,
//       plantType,
//       kwRequired,
//       account1,
//       mpeb1,
//       portal1,
//       bank,
//       totalProjectCost,
//       dcrInvoice,
//       receivedAmount,
//       pendingAmount,
//       tat,
//       status,
//       remark,
//     } = req.body;

//     let lead = await leadModel.findById(id);
//     if (!lead) return res.status(404).json({ message: "Lead not found" });

//     // ✅ Sirf apna lead update kar sakta hai
//     if (lead.assignedTo.toString() !== req.user.id) {
//       return res.status(403).json({ message: "Not authorized to update this lead" });
//     }

//     // ✅ Enquiry details update (partial allowed)
//     lead.enquiryDetails = {
//       ...lead.enquiryDetails,
//       promoter,
//       mobileNo,
//       structureType,
//       customerName,
//       plantType,
//       kwRequired,
//       account1,
//       mpeb1,
//       portal1,
//       bank,
//       totalProjectCost,
//       dcrInvoice,
//       receivedAmount,
//       pendingAmount,
//       tat,
//     };

//     // ✅ Status update
//     if (status) lead.status = status;

//     // ✅ Remark add
//     if (remark) {
//       lead.remarks.push({ text: remark, addedBy: req.user.id });
//     }

//     await lead.save();

//     // ✅ Populate data for response
//     lead = await leadModel.findById(id)
//       .populate("assignedTo", "fullName email role")
//       .populate("createdBy", "fullName email role");

//     res.status(200).json({
//       message: "Lead updated successfully by field executive",
//       lead,
//     });
//   } catch (err) {
//     console.error("❌ Error updating lead by executive:", err);
//     res.status(500).json({ message: "Server error" });
//   }
// };

// // Delete Lead
// exports.deleteLead = async (req, res) => {
//     try {
//         const { id } = req.params;
//         await leadModel.findByIdAndDelete(id);
//         res.status(200).json({ message: "Lead deleted successfully" });
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ message: "Server error" });
//     }
// };

// // telecaller.controller.js
// exports.assignLead = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const { fieldExecutive, loanAdmin, mpebAdmin, installationAdmin } = req.body;

//     let lead = await leadModel.findById(id);
//     if (!lead) return res.status(404).json({ message: "Lead not found" });

//     if (fieldExecutive) lead.assignedTo.fieldExecutive = fieldExecutive;
//     if (loanAdmin) lead.assignedTo.loanAdmin = loanAdmin;
//     if (mpebAdmin) lead.assignedTo.mpebAdmin = mpebAdmin;
//     if (installationAdmin) lead.assignedTo.installationAdmin = installationAdmin;

//     lead.status = "assigned"; // mark as assigned
//     await lead.save();

//     res.status(200).json({ message: "Lead assigned successfully", lead });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server error" });
//   }
// };


const leadModel = require("../models/lead.model");
const User = require("../models/user.model"); // Added to populate assignedTo details

// Create Lead (Can be used by SuperAdmin/Telecaller)
exports.createLead = async (req, res) => {
    try {
        const { name, email, phone, source, enquiryDetails } = req.body;

        const lead = new leadModel({
            name,
            email,
            phone,
            source: source || "telecaller", // Default source
            createdBy: req.user.id,
            enquiryDetails: enquiryDetails || {} // Initialize if not provided
        });

        await lead.save();
        res.status(201).json({ message: "Lead created successfully", lead });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
};

// Get all Leads (Admin, SuperAdmin, Telecaller, Field Executive - filtered)
exports.getAllLeads = async (req, res) => {
    try {
        let query = {};

        // If telecaller or superadmin or accounting admin, they can see all leads
        if (["telecaller", "superadmin", "accounting_admin", "admin"].includes(req.user.role)) {
            query = {};
        }
        // If field executive, only assigned leads
        else if (req.user.role === "fieldexecutive") {
            query = { assignedTo: req.user.id };
        }
        // If installation admin, only leads assigned to them for installation
        else if (req.user.role === "installation_admin") {
            query = { assignedTo: req.user.id, status: "installation" };
        }
        // If mpeb admin, only leads assigned to them for mpeb process
        else if (req.user.role === "mpeb_admin") {
            query = { assignedTo: req.user.id, status: "mpeb-process" };
        }
        // If loan admin, only leads assigned to them for loan process
        else if (req.user.role === "loan_admin") {
            query = { assignedTo: req.user.id, status: "loan-process" };
        }


        const leads = await leadModel.find(query)
            .populate("assignedTo", "fullName email role")
            .populate("createdBy", "fullName email role");

        res.status(200).json(leads);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
};

// Update Lead (General update by Telecaller/SuperAdmin - not restricted by assignedTo)
exports.updateLeadGeneral = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, email, phone, source, status, remark } = req.body; // Can update general fields

        let lead = await leadModel.findById(id);
        if (!lead) return res.status(404).json({ message: "Lead not found" });

        if (name) lead.name = name;
        if (email) lead.email = email;
        if (phone) lead.phone = phone;
        if (source) lead.source = source;
        if (status) lead.status = status; // Telecaller can update status

        if (remark) {
            lead.remarks.push({ text: remark, addedBy: req.user.id });
        }

        await lead.save();

        lead = await leadModel.findById(id)
            .populate("assignedTo", "fullName email role")
            .populate("createdBy", "fullName email role");

        res.status(200).json({ message: "Lead updated successfully", lead });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
};

// Delete Lead (by Telecaller/SuperAdmin)
exports.deleteLead = async (req, res) => {
    try {
        const { id } = req.params;
        const lead = await leadModel.findByIdAndDelete(id);
        if(!lead) return res.status(404).json({ message: "Lead not found" });
        res.status(200).json({ message: "Lead deleted successfully" });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
};

// Assign Lead (by Telecaller/SuperAdmin)
exports.assignLead = async (req, res) => {
  try {
    const { id } = req.params;
    const { assignedTo } = req.body; // User ID of the executive/admin to assign to

    let lead = await leadModel.findById(id);
    if (!lead) return res.status(404).json({ message: "Lead not found" });

    // Validate if assignedTo user exists and is a valid role for assignment
    const targetUser = await User.findById(assignedTo);
    if (!targetUser) {
        return res.status(400).json({ message: "Assigned user not found" });
    }
    // You might want to add role-specific checks here, e.g., cannot assign to a telecaller
    const assignableRoles = ["fieldexecutive", "installation_admin", "mpeb_admin", "loan_admin", "accounting_admin"];
    if (!assignableRoles.includes(targetUser.role)) {
        return res.status(400).json({ message: `Cannot assign lead to a user with role ${targetUser.role}` });
    }

    lead.assignedTo = assignedTo;
    // Update status based on the role it's assigned to using the exact enum values
    if (targetUser.role === "fieldexecutive") {
      lead.status = "assigned_to_fieldexecutive"; // Correct enum value
    } else if (targetUser.role === "installation_admin") {
      lead.status = "assigned_to_installationadmin"; // Correct enum value
    } else if (targetUser.role === "mpeb_admin") {
      lead.status = "assigned_to_mpebadmin"; // Correct enum value
    } else if (targetUser.role === "loan_admin") {
      lead.status = "assigned_to_loanadmin"; // Correct enum value
    } else if (targetUser.role === "accounting_admin") {
      lead.status = "assigned_to_accounting"; // Correct enum value
    } else {
        // Fallback for unexpected roles, though assignableRoles check should prevent this
        return res.status(400).json({ message: "Invalid role for assignment" });
    }

    await lead.save();

    res.status(200).json({ message: "Lead assigned successfully", lead });
  } catch (err) {
    console.error("❌ Error assigning lead:", err);
    res.status(500).json({ message: "Server error" });
  }
};