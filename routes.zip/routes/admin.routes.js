const express = require('express');
const router = express.Router();
const upload = require("../multer/multerImageVideo");
const uploadToSpaces = require("../middleware/uploadToSpaces");
const { authenticate, isAdmin } = require('../middleware/auth');
const authController = require('../controllers/authController')
const telecallerController = require('../controllers/telecaller.controller')

// Login Register======================================================================================================
router.post("/login", authController.login);

// Auth routes=========================================================================================================
router.use(authenticate, isAdmin);

// Login Register======================================================================================================
router.post("/register", upload.single("profileImage"), uploadToSpaces, authController.register);

// Lead routes=========================================================================================================
router.post("/create/lead", telecallerController.createLead);
router.get("/all/leads", telecallerController.getAllLeads);
router.put("/lead/:id", telecallerController.updateLeadGeneral);
router.delete("/lead/:id", telecallerController.deleteLead);

module.exports = router;