// const express = require('express');
// const router = express.Router();
// const { authenticate, isSuperAdmin } = require('../middleware/auth');
// const upload = require("../multer/multerImageVideo");
// const uploadToSpaces = require("../middleware/uploadToSpaces");
// const authController = require('../controllers/authController');
// const telecallerController = require('../controllers/telecaller.controller')

// // Login Register=======================================================================================================
// router.post("/register", upload.single("profileImage"), uploadToSpaces, authController.register);
// router.post("/login", authController.login);

// // Auth routes=========================================================================================================
// router.use(authenticate, isSuperAdmin);

// // Auth Register=======================================================================================================
// router.post("/register", upload.single("profileImage"), uploadToSpaces, authController.register);

// // Lead routes=========================================================================================================
// router.post("/create/lead", telecallerController.createLead);
// router.get("/all/leads", telecallerController.getAllLeads);
// router.put("/lead/:id", telecallerController.updateLead);
// router.delete("/lead/:id", telecallerController.deleteLead);

// module.exports = router;

const express = require('express');
const router = express.Router();
const { authenticate, isSuperAdmin } = require('../middleware/auth');
const upload = require("../multer/multerImageVideo"); // Ensure this path is correct
const uploadToSpaces = require("../middleware/uploadToSpaces"); // Ensure this path is correct
const authController = require('../controllers/authController');
const telecallerController = require('../controllers/telecaller.controller'); // For general lead ops

// Login Register (for SuperAdmin, but uses general authController)
router.post("/register", upload.single("profileImage"), uploadToSpaces, authController.register); // Register for all roles
router.post("/login", authController.login);

// Auth routes for SuperAdmin
router.use(authenticate, isSuperAdmin);

// SuperAdmin specific actions (they can do all telecaller actions)
router.post("/create/lead", telecallerController.createLead); // SuperAdmin can create leads
router.get("/all/leads", telecallerController.getAllLeads); // SuperAdmin can see all leads
router.put("/lead/:id", telecallerController.updateLeadGeneral); // SuperAdmin can update any lead generally
router.put("/assign/lead/:id", telecallerController.assignLead); // SuperAdmin can assign leads
router.delete("/lead/:id", telecallerController.deleteLead); // SuperAdmin can delete leads

// Other SuperAdmin specific routes (e.g., manage users, settings)
// router.get("/users", superadminController.getAllUsers);
// router.delete("/user/:id", superadminController.deleteUser);


module.exports = router;