// const mongoose = require("mongoose");

// const leadSchema = new mongoose.Schema(
//   {
//     name: { type: String, required: true }, // Lead ka naam
//     email: { type: String },
//     phone: { type: String },
//     source: { type: String, enum: ["website", "admin", "superadmin", "other"], default: "other" }, // Lead kahan se aayi
//     status: {
//       type: String,
//       enum: [
//         "new",              // Lead create hui
//         "assigned",         // Telecaller ne assign ki
//         "in-progress",      // Field executive ne follow up kiya
//         "installation",     // Installation admin ke paas gyi
//         "mpeb-process",     // MPEB admin ke paas gyi
//         "loan-process",     // Loan admin ke paas gyi
//         "accounting",       // Accounting admin ke paas gyi
//         "converted",        // Client me convert ho gayi
//         "rejected",          // Reject ho gayi
//         "completed",
//       ],
//       default: "new",
//     },
//     assignedTo: {
//       fieldExecutive: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
//       loanAdmin: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
//       mpebAdmin: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
//       installationAdmin: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
//     },
//     createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }, // Kisne create ki
//     remarks: [{
//       text: String,
//       addedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
//       date: { type: Date, default: Date.now }
//     }],
//     enquiryDetails: {
//       promoter: String,
//       mobileNo: String,
//       structureType: String,
//       customerName: String,
//       plantType: String,
//       kwRequired: Number,
//       account1: String,
//       mpeb1: String,
//       portal1: String,
//       bank: String,
//       totalProjectCost: Number,
//       dcrInvoice: String,
//       receivedAmount: Number,
//       pendingAmount: Number,
//       tat: String,
//     },
//     loanStatus: { type: String, enum: ["pending", "approved", "rejected"], default: "pending" },
//     mpebStatus: { type: String, enum: ["pending", "processed"], default: "pending" },
//     installationStatus: { type: String, enum: ["pending", "completed"], default: "pending" },
//     accountingStatus: { type: String, enum: ["pending", "completed"], default: "pending" },
//   },
//   { timestamps: true }
// );

// module.exports = mongoose.model("Lead", leadSchema);

const mongoose = require("mongoose");

const leadSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String },
    phone: { type: String },

    // Loan Process status
    status: {
      type: String,
      enum: [
        "new",
        "assigned_to_loanadmin",
        "loan_application_started",
        "loan_docs_uploaded",
        "loan_docs_review_pending",
        "loan_docs_verified",
        "loan_docs_rejected",
        "loan_emi_calculation_pending",
        "loan_emi_scheduled",
        "loan_final_approval_pending",
        "loan_approved",
        "loan_rejected"
      ],
      default: "new",
    },

    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },

    loanApplicationDetails: {
      requiredDocuments: {
        type: [String],
        default: ["Aadhar", "PAN", "Bank Passbook", "Photo"]
      },

      // हर डॉक्यूमेंट की Entry
      documents: [
        {
          type: {
            type: String,
            required: true,
            enum: [
              "Aadhar_Front",
              "Aadhar_Back",
              "PAN_Front",
              "PAN_Back",
              "Passport",
              "VoterID",
              "DrivingLicense",
              "LoanApplication",
              "PassportPhoto",
              "PropertyOwnership",
              "SaleAgreement",
              "TitleDeed",
              "UtilityBill",
              "AadhaarAddressProof",
              "PassportAddressProof",
              "RationCard",
              "RentAgreement",
              "DrivingLicenseAddressProof",
              "SalarySlip",
              "Form16",
              "ITR",
              "BusinessProof",
              "BankStatement"
            ]
          },
          url: { type: String, required: true },
          verificationStatus: {
            type: String,
            enum: ["pending", "verified", "rejected"],
            default: "pending"
          },
          uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
          uploadedAt: { type: Date, default: Date.now },
          verifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },   // ✅ Added
          verifiedAt: { type: Date }
        }
      ],

      // Loan financial details
      loanAmount: { type: Number },
      interestRate: { type: Number },
      tenureMonths: { type: Number },
      monthlyEmi: { type: Number },
      emiSchedule: [
        {
          dueDate: { type: Date },
          amount: { type: Number },
          status: { type: String, enum: ["pending", "paid", "overdue"], default: "pending" }
        }
      ],
      loanDisbursalDate: { type: Date },
      loanStatusReason: { type: String },
      approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },   // ✅ Added
      approvalDate: { type: Date },                                        // ✅ Added
      rejectedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },   // ✅ Added
      rejectedAt: { type: Date }
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Lead", leadSchema);
